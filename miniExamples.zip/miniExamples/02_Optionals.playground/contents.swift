// We already know about constants vs variables but there is another choice always present.
var x = 7
var f: Float = 7
let dave = "Dave"
//dave = "Bob"  // Would cause an error

// Part 1.
// Optionals





// Optionals with forced unwrapping










// Part 2.
// Views in a Playground + Optional Chaining








// Optional Binding








// Implicitly Unwrapped Optionals
